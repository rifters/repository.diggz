# SportsDevil_JX
This is an unofficial SportsDevil fork by JairoX. It is mainly based on Hubbab3's version but includes some additional sites.

Note that SportsDevil only searches and reproduces streams from sites that charge for the viewing of their streams through web banner advertising or otherwise. SportsDevil is intended for those who have clicked on endless ads but cannot access the stream due to faulty web site setups. **SportsDevil does not provide or host any streams of its own; stream quality, content and copyright are responsibility of the ad-financed source web sites.**